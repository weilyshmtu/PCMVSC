% This code runs the LMVSC algorithm on Caltech7 dataset and records its
% performance. The results are output in *.txt format.

% Notice: The dataset is organized in a cell array with each element being
% a view. Each view is represented by a matrix, each row of which is a
% sample.

% The core of LMVSC is encapsulated in an independent matlab function.
% Visit lmv.m directly, if you want to learn the details of its
% implementation.

clear;
addpath('../Multiview datasets/')
addpath('./LMVSC/')
datasets = ["3sources", "MSRC_v1", "BBCsport", "100Leaves", "WebKB", "Handwritten", "Caltech101-20", "WikipediaArticles"];


for d_ind=1:length(datasets)
    load(datasets(d_ind));
    filename = "LMVSC_" + datasets(d_ind)+ ".txt";
    fileID = fopen(filename, 'wt');

    normX = normlize(X);  % l2 norm
   
    n_views=length(X);
    n_calsses=length(unique(Y));
    if min(unique(Y)) == 0
        n_calsses = n_calsses + 1;
    end
    
    % Parameter 1: number of anchors (tunable)
    param1_set=[n_calsses 50 100];
    
    % Parameter 2: alpha (tunable)
    param2_set=[.01 0.1 1 100];
    
    for j=1:length(param1_set)
        
        % Perform K-Means on each view
        for i=1:n_views
            rand('twister',5489);
            [~, H{i}] = litekmeans(X{i},param1_set(j),'MaxIter', 100,'Replicates',10);
        end
    
        for i=1:length(param2_set)
            fprintf('params:\tnumanchor=%d\t\talpha=%f\n',param1_set(j),param2_set(i));
            tic;
            
            % Core part of this code (LMVSC)
            [F,ids] = LMVSC(X',Y,H,param2_set(i));
            
            % Performance evaluation of clustering result
            result=Clustering8Measure(ids,Y);
            
            t=toc;
            fprintf('result:\t%12.6f %12.6f %12.6f %12.6f\n',[result t]);
            
            % Write the evaluation results to a text file
            param = [param2_set(i), param1_set(j)];
            for p_ind = 1:length(param) 
                fprintf(fileID, " param_" + num2str(p_ind)+": " + num2str(param(p_ind)));
            end
            fprintf(fileID, " acc: %4.2f, nmi: %4.2f, ari: %4.2f, Fscore: %4.2f\n", result(1)*100, result(2)*100, result(3)*100, result(4)*100);  
            
        end
    end
end


function normX = normlize(X)
    n = size(X{1},1) ;
    for i=1:length(X)
        tX = X{i};
        for j=1:n
            tX(j,:) = tX(j,:)/norm(tX(j,:),2);
        end
        normX{i} = tX;
    end
end