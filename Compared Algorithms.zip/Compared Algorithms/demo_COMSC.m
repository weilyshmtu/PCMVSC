clear
clc
warning off


addpath('..\Multiview datasets')
addpath('.\COMSC\eval\')
addpath('.\COMSC\')
datasets = ["3sources", "MSRC_v1", "BBCsport", "100Leaves", "WebKB", "Handwritten", "Caltech101-20", "WikipediaArticles"];


for d_ind=1:length(datasets)
    filename = "COMSC_" + datasets(d_ind)+ ".txt";
    fileID = fopen(filename, 'wt');
    load(datasets(d_ind))
    
    X = normalize_data(X);
    n_classes = length(unique(Y));
    n_views = size(X, 2);
    for i=1:n_views
        X{i}= X{i}';
    end
    smp_num = size(X{1}, 2);
    
    % compute kernels
    
    ker_num = n_views*5;
    K = zeros(smp_num, smp_num, ker_num);
    for v=1:n_views
        options.KernelType = 'Gaussian';
        K(:,:,1+(v-1)*5) = construct_kernel(X{v}', [], options);
        options.KernelType = 'Polynomial';
        options.d = 3;
        K(:,:,2+(v-1)*5) = construct_kernel(X{v}', [], options);
        options.KernelType = 'Linear';
        K(:,:,3+(v-1)*5) = construct_kernel(X{v}', [], options);
        options.KernelType = 'Sigmoid';
        options.c = 0;
        options.d = 0.1;
        K(:,:,4+(v-1)*5) = construct_kernel(X{v}', [], options);
        options.KernelType = 'InvPloyPlus';
        options.c = 0.01;
        options.d = 1;
        K(:,:,5+(v-1)*5) = construct_kernel(X{v}', [], options);
    end
    
    % center and normalized kernels
    K = kcenter(K);
    K = knorm(K);
    
    % parameters
    param1_set = [1:1:20]*n_classes;
    len_param1_set = length(param1_set);
    param2_set = 2.^[-10:2:10];
    len_param2_set = length(param2_set);
    param3_set = [0.5,1,5,10];%2^0; % always set to 1, for it is not discussed in the paper
    len_param3_set = length(param3_set);
    max_iter = 20;
    
    metrics_meaning = {'acc'; 'nmi'; 'purity'; 'AR'; 'RI'; 'MI'; 'HI'; 'fscore'; 'precision'; 'recall'};
    
    for ic=1:length(param1_set)
        if param1_set(ic)>=smp_num
          break;
        end
        for il=1:len_param2_set
            for ij= 1:len_param3_set
          % main algorithm
              [Z, ~, ~, ~, ~ ] = CoMSC(K, param1_set(ic), param2_set(il), param3_set(ij), max_iter);
              PI = Z > 0;
              Z = Z.*PI;
              [U] = baseline_spectral_onkernel( abs( (Z + Z') / 2) , n_classes);
              [y] = my_kmeans(U, n_classes);
              [result] = my_eval_y(y, Y);
              param = [param1_set(ic), param2_set(il), param3_set(ij)];
                for p_ind = 1:length(param) 
                    fprintf(fileID, " param_" + num2str(p_ind)+": " + num2str(param(p_ind)));
                end
                fprintf(fileID, " acc: %4.2f, nmi: %4.2f, ari: %4.2f, Fscore: %4.2f\n", result(1)*100, result(2)*100, result(3)*100, result(4)*100);  
            end
        end
    end

end