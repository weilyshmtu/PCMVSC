%% LMSC (CVPR-17)

clear
clc
datasets = ["3sources", "MSRC_v1", "BBCsport", "100Leaves", "WebKB", "Handwritten", "Caltech101-20", "WikipediaArticles"];
addpath('..\Multiview datasets\')
addpath('.\LMSC\')
addpath('.\LMSC\ClusteringMeasure\')
addpath('.\LMSC\LRR\')


for d_ind=1:length(datasets)
    load(datasets(d_ind));
    filename = "LMSC_" + datasets(d_ind)+ ".txt";
    fileID = fopen(filename, 'wt');

    n_classes = max(unique(Y));
    if min(unique(Y)) == 0
        n_classes = n_classes + 1;
    end

    for d_ind =1:length(X)
        X{d_ind} = X{d_ind}';
    end
    
    param1_set = [0.01,0.1,1,10];
    param2_set = [50,100,150,200];

    for i= 1:length(param1_set)
        for j = 1:length(param2_set)
            [nmi,ACC,f,ARI,H] = LRMSC(X,Y,n_classes,param1_set(i),param2_set(j));
            param = [param1_set(i),param2_set(j)];
            for p_ind = 1:length(param) 
                fprintf(fileID, " param_" + num2str(p_ind)+": " + num2str(param(p_ind)));
            end
            fprintf(fileID, " acc: %4.2f, nmi: %4.2f, ari: %4.2f, Fscore: %4.2f\n", ACC*100, nmi*100, ARI*100, f*100);  
        end
    end
end


function normX = normlize(X)  % LMSC has its now normalization
    n = size(X{1},1) ;
    for i=1:length(X)
        tX = X{i};
        for j=1:n
            tX(j,:) = tX(j,:)/norm(tX(j,:),2);
        end
        normX{i} = tX;
    end
end