%% Experiments on real-world data sets
% Graph-based Multi-view Clustering (GMC)
%
%%
clc;  close all; clear all;
currentFolder = pwd;
addpath(genpath(currentFolder));
addpath('..\Multiview datasets')
datasets = ["3sources", "MSRC_v1", "BBCsport", "100Leaves", "WebKB", "Handwritten", "Caltech101-20", "WikipediaArticles"];

rtimes = 1; % run-times on each dataset, default: 1



param1_set = [0.5,1,3,5];
param2_set = [5,10,15,20];
for idata = 1:length(datasets)
    load(datasets(idata));
    
    filename = "GMC_" + datasets(idata) + ".txt";
    fileID = fopen(filename, 'wt');

    for d_ind =1:length(X)   % let each column of Xi represent a data sample
        X{d_ind} = X{d_ind}';
    end
    n_classes = max(unique(Y));
    if min(unique(Y)) == 0
        n_classes = n_classes + 1;
    end
    %% iteration ...
    for ik=1:length(param2_set)
        for ilambda=1:length(param1_set)
            predY = GMC(X, param2_set(ik), param1_set(ilambda), n_classes,1); % c: the # of clusters
            metric = Clustering8Measure(Y, predY');
            acc = metric(1);
            nmi = metric(2);
            ari = metric(3);
            Fscore = metric(4);
            param = [param2_set(ik), param1_set(ilambda)];
            for p_ind = 1:length(param) 
                fprintf(fileID, " param_" + num2str(p_ind)+": " + num2str(param(p_ind)));
            end
            fprintf(fileID, " acc: %4.2f, nmi: %4.2f, ari: %4.2f, Fscore: %4.2f\n", acc*100, nmi*100, ari*100, Fscore*100);  
        end
    end
end;


function normX = normlize(X)  % GMC has its now normalization
    n = size(X{1},1) ;
    for i=1:length(X)
        tX = X{i};
        for j=1:n
            tX(j,:) = tX(j,:)/norm(tX(j,:),2);
        end
        normX{i} = tX;
    end
end