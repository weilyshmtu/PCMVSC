clc;
clear
close all


datasets = ["3sources", "MSRC_v1", "BBCsport", "100Leaves", "WebKB", "Handwritten", "Caltech101-20", "WikipediaArticles"];
addpath('..\Multiview datasets')
addpath('.\SWMVC\')

% parameter setting
param1_set = [0.5,1,5,10];
param2_set = [5,10,15,20,25];

for d_ind=1:length(datasets)
    load(datasets(d_ind));

    filename = "SWMVC_" + datasets(d_ind)+ ".txt";
    fileID = fopen(filename, 'wt');
    
    normX = normlize(X);   % l2-norm
    X = normX;

    n_classes = max(unique(Y));
    if min(unique(Y))==0
        n_classes = n_classes+1;
    end

    
    % =====================  run =====================
    for k=1:length(param2_set)
        for i=1:length(X)
            WW{i} = constructW_PKN(X{i}', param2_set(k));
        end
        for alpha=1:length(param1_set)
                result = SwMC(WW, Y, n_classes,param1_set(alpha))
                param = [param1_set(alpha), param2_set(k)];
                for p_ind = 1:length(param) 
                    fprintf(fileID, " param_" + num2str(p_ind)+": " + num2str(param(p_ind)));
                end
                fprintf(fileID, " acc: %4.2f, nmi: %4.2f, ari: %4.2f, Fscore: %4.2f\n", result(1)*100, result(2)*100, result(3)*100, result(4)*100);  

        end
    end
end

function normX = normlize(X)
    n = size(X{1},1) ;
    for i=1:length(X)
        tX = X{i};
        for j=1:n
            tX(j,:) = tX(j,:)/(norm(tX(j,:),2)+eps);
        end
        normX{i} = tX;
    end
end