clc;
clear
close all

% parameter setting
param1_set = [0.1,0.5,1,5,10,50];
param2_set = [0.1,0.5,1,5,10,50];
param3_set = [5,10,15,20,25];

datasets = ["3sources", "MSRC_v1", "BBCsport", "100Leaves", "WebKB", "Handwritten", "Caltech101-20", "WikipediaArticles"];
addpath('..\Multiview datasets')
addpath('./MVSCTM/')

for d_ind=1:length(datasets)
    load(datasets(d_ind));


    filename = "MVSCTM_" + datasets(d_ind)+ ".txt";
    fileID = fopen(filename, 'wt');
    
    n_classes = max(unique(Y));
    if min(unique(Y))==0
        n_classes = n_classes+1;
    end
    normData=1;
    
    % =====================  run =====================
    for k=1:length(param3_set)
        for alpha=1:length(param1_set)
            for beta = 1:length(param2_set)
                result = MVCsubspace_TM(X,Y, param1_set(alpha), param2_set(beta), param3_set(k), normData)
                param = [param1_set(alpha), param2_set(beta), param3_set(k)];
                for p_ind = 1:length(param) 
                    fprintf(fileID, " param_" + num2str(p_ind)+": " + num2str(param(p_ind)));
                end
                fprintf(fileID, " acc: %4.2f, nmi: %4.2f, ari: %4.2f, Fscore: %4.2f\n", result(1)*100, result(2)*100, result(3)*100, result(4)*100);  

            end
        end
    end
end


function normX = normlize(X)   % MVSCTM has its normalization
    n = size(X{1},1) ;
    for i=1:length(X)
        tX = X{i};
        for j=1:n
            tX(j,:) = tX(j,:)/(norm(tX(j,:),2)+eps);
        end
        normX{i} = tX;
    end
end