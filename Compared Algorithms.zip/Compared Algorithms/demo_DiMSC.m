
clear
clc
addpath('..\Multiview datasets')
addpath('.\DiMSC\ClusteringMeasure')
addpath('.\DiMSC')
datasets = ["3sources", "MSRC_v1", "BBCsport", "100Leaves", "WebKB", "Handwritten", "Caltech101-20", "WikipediaArticles"];
param1_set = [0.01, 0.02, 0.03];
param2_set = 20:20:200;


for d_ind=1:length(datasets)
    load(datasets(d_ind))
  
    filename = "DiMSC_" + datasets(d_ind)+ ".txt";
    fileID = fopen(filename, 'wt');

    normX = normlize(X); % l2-norm 
    for d_ind =1:length(X)   % let each column of Xi represent a data sample
        X{d_ind} = normX{d_ind}';
    end
    
    n_classes = max(unique(Y));
    if min(unique(Y)) == 0
        n_classes = n_classes + 1;
    end


    for p1_ind = 1:length(param1_set)
        for p2_ind = 1:length(param2_set)
        param1 = param1_set(p1_ind);
        param2 = param2_set(p2_ind);
        [acc nmi ari Fscore] = diverse_msc(X,Y,param1,param2)
        param = [param1, param2];
            for p_ind = 1:length(param) 
                fprintf(fileID, "param_" + num2str(p_ind)+": " + num2str(param(p_ind)));
            end
        fprintf(fileID, " acc: %4.2f, nmi: %4.2f, ari: %4.2f, Fscore: %4.2f\n", acc*100, nmi*100, ari*100, Fscore*100);          
        end
    end
end


function normX = normlize(X)
    n = size(X{1},1) ;
    for i=1:length(X)
        tX = X{i};
        for j=1:n
            tX(j,:) = tX(j,:)/(norm(tX(j,:),2)+eps);
        end
        normX{i} = tX;
    end
end