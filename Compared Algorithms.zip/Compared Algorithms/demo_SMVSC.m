clear;
clc;
warning off;
datasets = ["3sources", "MSRC_v1", "BBCsport", "100Leaves", "WebKB", "Handwritten", "Caltech101-20", "WikipediaArticles","20newsgroups"];
addpath('..\Multiview datasets')
addpath('.\SMVSC\')
param1_set=[0.5,1,5];

for d_ind=1:length(datasets)
    load(datasets(d_ind));
    % filename = "SMVSC_" + datasets(d_ind)+ ".txt";
    % fileID = fopen(filename, 'wt');
    
    normX = normlize(X);  % l2 normalization

    n_classes = length(unique(Y));
    param2_set = [n_classes 2*n_classes 3*n_classes];

    for ilambda = 1:length(param1_set)
        for ia = 1:length(param2_set)
            tic;
            [U,V,A,W,Z,iter,obj] = algo_qp(X,Y,param1_set(ilambda),n_classes,param2_set(ia)); % X,Y,lambda,d,numanchor
            result = myNMIACCwithmean(U,Y,n_classes);
            timer  = toc;
            fprintf('Anchor:\t%d \t ACC:%12.6f \t NMI:%12.6f \t Purity:%12.6f \t Fscore:%12.6f \t Time:%12.6f \n',[param2_set(ia) result(1) result(2) result(3) result(4) timer]);
            param = [param1_set(ilambda),param2_set(ia)];
            for p_ind = 1:length(param) 
                fprintf(fileID, " param_" + num2str(p_ind)+": " + num2str(param(p_ind)));
            end
            fprintf(fileID, " acc: %4.2f, nmi: %4.2f, ari: %4.2f, Fscore: %4.2f\n", result(1)*100, result(2)*100, result(3)*100, result(4)*100);  
        end
    end
end


function normX = normlize(X)
    n = size(X{1},1) ;
    for i=1:length(X)
        tX = X{i};
        for j=1:n
            tX(j,:) = tX(j,:)/norm(tX(j,:),2);
        end
        normX{i} = tX;
    end
end