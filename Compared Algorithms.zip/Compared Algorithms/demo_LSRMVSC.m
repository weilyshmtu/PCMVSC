clc;
clear
close all

% parameter setting
param1_set = [1e2, 1e3, 1e4];
param2_set = [10,20,30,40,50];
param3_set = [1,2,3,4,5];

datasets = ["3sources", "MSRC_v1", "BBCsport", "100Leaves", "WebKB", "Handwritten", "Caltech101-20", "WikipediaArticles"];
addpath('..\Multiview datasets')
addpath('./LSRMVSC/')

for d_ind=1:length(datasets)
    load(datasets(d_ind));

    filename = "LSRMVSC_" + datasets(d_ind)+ ".txt";
    fileID = fopen(filename, 'wt');

    % =====================  run =====================
    for k=1:length(param3_set)
        for eta=1:length(param1_set)
            for gamma = 1:length(param2_set)
                result = LSRMSC(X, Y,param1_set(eta), param2_set(gamma), param3_set(k))
                param = [param1_set(eta), param2_set(gamma), param3_set(k)];
                for p_ind = 1:length(param) 
                    fprintf(fileID, " param_" + num2str(p_ind)+": " + num2str(param(p_ind)));
                end
                fprintf(fileID, " acc: %4.2f, nmi: %4.2f, ari: %4.2f, Fscore: %4.2f\n", result(1)*100, result(2)*100, result(3)*100, result(4)*100);  
            end
        end
    end
end