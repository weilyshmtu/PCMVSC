clear;
clc;
close all;

datasets = ["3sources", "MSRC_v1", "BBCsport", "100Leaves", "WebKB", "Handwritten", "Caltech101-20", "WikipediaArticles"];
addpath('..\Multiview datasets')
addpath('.\SLMVGC\')

param1_set = [10,50,100,150];
param2_set = [0.001,0.005,0.01,0.1,1];
param3_set = [0.1,0.5,1,5];
param4_set = [0.01,0.05,0.1,1,10,50];

for d_ind=1:length(datasets)
    load(datasets(d_ind));
    filename = "SLMVGC_" + datasets(d_ind)+ ".txt";
    fileID = fopen(filename, 'wt');
    X = normlize(X);

% For HW2, the preferable parameter setting is: alpha=50  beta = 0.005
% lambda = 0.5  gamma = 0.05
% For ORL_mtv, the preferable parameter setting is: alpha = 100  beta =
% 0.01  lambda = 1  gamma = 10
    
    for alpha=1:length(param1_set)
        for beta = 1:length(param2_set)
            for lambda = 1:length(param3_set)
                for gamma = 1:length(param4_set)
                    result = SLMVGC(X, Y, param1_set(alpha), param2_set(beta), param3_set(lambda), param4_set(gamma));   %acc, nmi, Pu, Fscore, Precision, Recall, ARI
                    param = [param1_set(alpha), param2_set(beta), param3_set(lambda), param4_set(gamma)];
                    for p_ind = 1:length(param) 
                        fprintf(fileID, " param_" + num2str(p_ind)+": " + num2str(param(p_ind)));
                    end
                    fprintf(fileID, " acc: %4.2f, nmi: %4.2f, ari: %4.2f, Fscore: %4.2f\n", result(1)*100, result(2)*100, result(3)*100, result(4)*100);  
                end
            end
        end
    end   
end



function normX = normlize(X)    % SLMVGC has its normalization
    n = size(X{1},1) ;
    for i=1:length(X)
        tX = X{i};
        for j=1:n
            tX(j,:) = tX(j,:)/(norm(tX(j,:),2)+eps);
        end
        normX{i} = tX;
    end
end