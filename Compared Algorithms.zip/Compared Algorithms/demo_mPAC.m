clear
clc

addpath('..\Multiview datasets')
param1_set=[10 20 30];
param2_set=[.001 .01 .1];
param3_set=[.000001 .00001 .0001];
datasets = ["3sources", "MSRC_v1", "BBCsport", "100Leaves", "WebKB", "Handwritten", "Caltech101-20", "WikipediaArticles"];


for d_ind=1:length(datasets)
    filename = "mPAC_" + datasets(d_ind)+ ".txt";
    fileID = fopen(filename, 'wt');

    load(datasets(d_ind))
    % normX = normlize(X); % l2-norm
    X= X';

    for i=1:size(X,1)
        dist = max(max(X{i})) - min(min(X{i}));
        m01 = (X{i} - min(min(X{i})))/dist;
        X{i} = 2 * m01 - 1;
    end
    [v1,v2]=size(X);
    FV=cell(v1,v2);
    SV=cell(v1,v2);
    LV=cell(v1,v2);

    for i=1:v1
        Sv= constructW_PKN(X{v1}', 5, 1);
        D = diag(sum(Sv));
        Lv = D-Sv;
        [Fv, ~, ev]=eig1(Lv,length(unique(Y)),0);
        FV{i}=Fv;
        SV{i}=Sv;
        LV{i}=Lv;
    end
    
    B=cell(size(X));
    for i=1:length(param1_set)
        for ii=1:size(X,1)
            B{ii}= inv(X{ii}*X{ii}'+param1_set(i)*eye(size(X{1},1)));
        end
        for j=1:length(param2_set)
            for k=1:length(param3_set)
                [result,FVret,obj,Wv]=UMVSC(X,Y,B,param1_set(i),param2_set(j),param3_set(k),FV,SV,LV);
                param = [param1_set(i),param2_set(j),param3_set(k)];
                for p_ind = 1:length(param) 
                    fprintf(fileID, " param_" + num2str(p_ind)+": " + num2str(param(p_ind)));
                end
                fprintf(fileID, " acc: %4.2f, nmi: %4.2f, ari: %4.2f, Fscore: %4.2f\n", result(1)*100, result(2)*100, result(3)*100, result(4)*100);  
            end
        end
    end
          %result = [Fscore Precision Recall nmi AR]  
end


function normX = normlize(X)
    n = size(X{1},1) ;
    for i=1:length(X)
        tX = X{i};
        for j=1:n
            tX(j,:) = tX(j,:)/norm(tX(j,:),2);
        end
        normX{i} = tX;
    end
end